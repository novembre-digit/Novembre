---
name: seo-check
description: Audit SEO on-page d'une landing page HTML statique (Novembre / retail design SEA). À utiliser quand l'utilisateur demande un "audit SEO", un "seo-check", de "vérifier le SEO" d'une page, ou avant de mettre une landing page en ligne pour du trafic Google Ads. Vérifie title/meta, hiérarchie Hn, mot-clé cible, données structurées, Open Graph, liens/assets cassés, alt, performance de chargement.
---

# SEO check — landing pages Novembre

Audit SEO on-page d'une landing page HTML statique de ce dépôt (ex. `retail-design-brand-experience/index.html`). Ces pages reçoivent du trafic **Google Ads** : le Quality Score dépend de la pertinence et de l'expérience de la page d'atterrissage, donc le SEO on-page compte autant pour le SEA que pour le référencement naturel.

## Entrée

- Cible : le fichier `index.html` de la page indiquée par l'utilisateur (par défaut, la page en cours de travail).
- Contexte de marque : `Novembre`, 3 agences (Paris / Strasbourg / Angers), déploiement Europe. Chaque page pilier vise un mot-clé principal (ex. `retail design`, `pop-up store`, `stand salon`…). Déduis le mot-clé cible de l'URL/slug du dossier et du `<title>`.

## Procédure

Lis le `<head>` et le corps de la page, puis vérifie chaque point ci-dessous. Utilise des vérifications déterministes quand c'est possible (longueurs, comptages, présence de balises). Un petit script Python est plus fiable que l'œil pour les longueurs et les comptages.

### 1. Balises méta essentielles
- `<title>` present, **≤ 60 caractères**, mot-clé cible en tête.
- `<meta name="description">` present, **≤ 155 caractères**, contient le mot-clé + un appel à l'action.
- `<link rel="canonical">` présent et pointant vers l'URL de production (pas localhost, pas de `../`).
- `<html lang="fr">` présent.
- `<meta name="viewport">` présent.

### 2. Titres (Hn)
- **Exactement un `<h1>`**, contenant le mot-clé cible **littéralement** (pas seulement dans un eyebrow/`<span>`).
- Hiérarchie cohérente : pas de saut de niveau (h1 → h3 sans h2). Chaque section a un `<h2>`.
- Pas de mot-clé sur-optimisé/répété à l'excès (keyword stuffing).

### 3. Partage social (Open Graph / Twitter)
- `og:type`, `og:title`, `og:description`, `og:url`, `og:site_name`, `og:locale` présents.
- `twitter:card` cohérent avec la présence d'image : `summary_large_image` **seulement si** une vraie image existe, sinon `summary`.
- **Ne jamais référencer une image (`og:image`/`twitter:image`) qui n'existe pas** — une image cassée est pire qu'absente.

### 4. Données structurées (JSON-LD)
- Bloc `application/ld+json` présent et **JSON valide** (parser avec `json.loads`).
- Type pertinent (`ProfessionalService` / `Organization`) avec `name`, `url`, `description`, `address`, `areaServed`.

### 5. Images
- Toutes les `<img>` de contenu ont un `alt` descriptif (les visuels purement décoratifs peuvent avoir `alt=""`).
- `loading="lazy"` sur les images sous la ligne de flottaison.
- Les placeholders (blocs sans vraie photo) n'ont pas besoin d'alt tant qu'ils ne sont pas des `<img>`.

### 6. Liens & assets
- Aucun `href="#"` mort présenté comme un vrai lien de contenu (les CTA d'ancrage internes `#section` sont OK).
- Vérifier que les assets référencés existent réellement sur le disque (CSS, JS, images, favicon, logos) — chemins relatifs corrects.
- Maillage interne : si les autres pikier/landing pages existent, lier vers elles (structure hub-and-spoke).

### 7. Performance de chargement
- Police chargée via `<link>` dans le `<head>` (+ `preconnect`), **pas** via `@import` dans le CSS (bloquant).
- Pas de dépendance externe superflue.

### 8. Cohérence SEA / champ sémantique
- Le champ sémantique de la page couvre les mots-clés de la/les campagne(s) Google Ads visée(s).
- Aucun contenu attirant les **mots-clés négatifs** (emploi, stage, définition, gratuit, pas cher, particulier, meuble IKEA, déco anniversaire…). Rester 100 % B2B/marque.
- Une politique de confidentialité est accessible (exigence Google Ads) — au moins un lien vers `/donnees-personnelles/`.

## Sortie

Produire un rapport concis classé **par impact** (🔴 haute / 🟡 moyenne / 🟢 à surveiller). Pour chaque problème : le constat, la ligne/fichier concerné, et la correction recommandée. Terminer par ce qui est déjà conforme (liste courte).

Ne PAS appliquer les corrections automatiquement sauf si l'utilisateur le demande — présenter d'abord le rapport, puis proposer de corriger.

## Exemple de vérification déterministe

```python
import re, json, os
html = open(PATH, encoding='utf-8').read()
title = re.search(r'<title>(.*?)</title>', html, re.S)
desc  = re.search(r'name="description"\s+content="(.*?)"', html, re.S)
print('title len', len(title.group(1)) if title else 'MANQUANT')
print('desc len',  len(desc.group(1))  if desc  else 'MANQUANT')
print('h1 count', len(re.findall(r'<h1[ >]', html)))
print('canonical', 'oui' if 'rel="canonical"' in html else 'MANQUANT')
m = re.search(r'<script type="application/ld\+json">(.*?)</script>', html, re.S)
try: json.loads(m.group(1)); print('json-ld: valide')
except Exception as e: print('json-ld: INVALIDE', e)
```
